Please unzip the folder first
javac *java
java Main.java >>>> for the first part
java Algo1.java >>>> for the secon part 
java Algo2.java >>>> for the second part