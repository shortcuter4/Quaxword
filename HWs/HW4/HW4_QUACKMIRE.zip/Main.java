/**
 *
 * @authors
 *
 * Subhan Ibrahimli
 * A. Berkay Bal
 * Mehmet Selim Özcan
 * Kaan Tapucu
 * Pegah Soltani
 *
 * @date 23.04.2020
 */

public class Main {

    // top node with child nodes
    private LinkedListTree head = new LinkedListTree();
    private LinkedListTree LCN = new LinkedListTree();
    private LinkedListTree RCN = new LinkedListTree();

    // jugs constraints
    private Jugs jugs = new Jugs();
    private int binaryIncrementer = 0;

    // main function
    public static void main(String[] args) {

        // constructor
        Main main = new Main();

        int jug3L=main.jugs.Jugs3L, jug7L=main.jugs.Jugs7L, V3L=main.jugs.V3L, V7L=main.jugs.V7L;

        // (cm)*a + (cn)*b = c
        //  a = 3, b = 5, c = 5
        //  m>0>n
        // Find min|ma| or min|mb|
        main.build(jug3L,jug7L,V3L,V7L);

        // print optimum steps
        main.init();
    }

    // print steps
    private void init(){

        System.out.println("\n<--------------Water Jug Problem Analysis------------------>");

        // validity
        if(LCN==null) return;

        // initial step
        System.out.print("Optimum Conclusion: " + "("+head.x+","+head.y+")");
        binaryIncrementer = 1;

        // check whether requested step is reached
        LinkedListTree mysteps = LCN;

        do {
            System.out.print(" --> ");
            System.out.print("(" + mysteps.x + "," + mysteps.y + ")");

            mysteps = mysteps.next;
            binaryIncrementer++;
        } while (mysteps != null && (mysteps.x >= 0 || mysteps.y >= 5));

        System.out.println("\nMinimum amount of steps: " + binaryIncrementer);

    }

    // check whether tree is valid
    private boolean validate(LinkedListTree next, int jug7L, int jug3L, int V1, int V2) {

        if((next.x == V1) && (next.y == V2)) return true;
        if((next.x == jug7L) && ( next.y == jug3L )||( next.x == 0 )&&( next.y == 0)) return false;

        // recursively check loop conditions, if any exists then return invalid
        return checkSubTree(LCN, next) && checkSubTree(RCN, next);
    }

    private boolean checkSubTree(LinkedListTree dumm, LinkedListTree next){

        // check loop condition in subtrees
        do {
            if((dumm.x == next.x) && (dumm.y == next.y)) return false;
            else dumm = dumm.next;
        }while (dumm != null);

        return true;
    }

    // check whether any invalid drop / pour / liquid transfer occurs
    private LinkedListTree stepNext( LinkedListTree stationaary, int jug7L, int jug3L, int V7L, int V3L) {

        LinkedListTree next=new LinkedListTree();

        if (    checkInvalidSteps( jug7L, stationaary.y, next, jug7L, jug3L, V7L, V3L )
            ||  checkInvalidSteps( stationaary.x, jug3L, next, jug7L, jug3L, V7L, V3L )
            ||  checkInvalidSteps( 0, stationaary.y, next, jug7L, jug3L, V7L, V3L )
            ||  checkInvalidSteps( stationaary.x, 0, next, jug7L, jug3L, V7L, V3L )
        ) return next;

        int destiny;
        // jug3L is not full and jug7L is not empty
        if(stationaary.y < jug3L && stationaary.x != 0) {
            destiny = jug3L - stationaary.y;
            // jug3L is not full and jug7L is not empty
            if(destiny >= stationaary.x){
                next.x = 0;
                next.y = stationaary.y+stationaary.x;
            }
            else {
                next.x = stationaary.x - destiny;
                next.y = stationaary.y + destiny;
            }
            if(validate( next, jug7L, jug3L, V7L, V3L )) return next;
        }
        if(stationaary.x < jug7L && stationaary.y != 0 ){
            destiny = jug7L - stationaary.x;
            if(destiny>=stationaary.y){
                next.y=0;
                next.x=stationaary.x+stationaary.y;
            }
            else {
                next.y=stationaary.y-destiny;
                next.x=stationaary.x+destiny;

            }
            if(validate( next, jug7L, jug3L, V7L, V3L )) return next;
        }
        return null;

    }

    private boolean checkInvalidSteps(int nextX, int nextY, LinkedListTree next, int jug7L, int jug3L, int V7L, int V3L){
        next.x=nextX;
        next.y=nextY;
        return validate( next, jug7L, jug3L, V7L, V3L );
    }

    // create the tree
    private void build( int jug7L, int jug3L, int V7L, int V3L ) {
        // top and children
        head = establishPriorities( 0, 0 );
        LCN = establishPriorities( 0, jug3L );
        RCN = establishPriorities( jug7L, 0 );

        // dummy children to use for search
        LinkedListTree dummLCN = LCN, dummRCN = RCN;

        // keep building children a& check whether a child that satisfies targeted amounts for both jugs appears
        while (!( dummRCN.x == V7L && dummRCN.y == V3L) ) {
            dummLCN = searchSubtree( dummLCN, jug7L, jug3L, V7L, V3L);   // left child
            dummRCN = searchSubtree( dummRCN, jug7L, jug3L, V7L, V3L);   // right child
        }
    }

    // update liquid amounts in jugs
    private LinkedListTree establishPriorities( int newX, int newY ) {
        LinkedListTree treeComponent = new LinkedListTree();
        treeComponent.x = newX;
        treeComponent.y = newY;
        treeComponent.next = null;

        return treeComponent;
    }

    // function to search children
    LinkedListTree searchSubtree(LinkedListTree child, int jug7L, int jug3L, int V7L, int V3L) {
        if( child.x != V7L || child.y != V3L ) {
            child.next = stepNext( child,jug7L, jug3L,V7L, V3L);
            child = child.next;
            assert child != null;
            child.next = null;
        }
        return child;
    }
}

// Supportive Instance Creators
class LinkedListTree {
    LinkedListTree next=null;
    int x=0,y=0;
}

class Jugs {
    int Jugs3L=3;
    int Jugs7L=7;

    final int V3L=0;
    final int V7L=5;
}
