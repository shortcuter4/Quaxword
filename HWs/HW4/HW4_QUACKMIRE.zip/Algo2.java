/**
 *
 * @authors
 *
 * Subhan Ibrahimli
 * A. Berkay Bal
 * Mehmet Selim Özcan
 * Kaan Tapucu
 * Pegah Soltani
 *
 * @date 23.04.2020
 */

public class Algo2 {
  public static void main ( String[] args ) {
    // variables
    int m,n,d,k;   // we need this variables for Diophantine equations
    int x, y;
    boolean check;
    
    // implementation
    
    // mx + ny = d
    m = 3;
    n = 7;
    d = 5;
    
    // these values are for the actual pouring sequence (integer sequence)
    x = 0;
    y = 0;
    check = true;
    
    k = 0;
    int gcd_res = gcd( m, n );  // it finds the greatest common divisor of m and n values.
    
    /* The Diophantine equation mx+ny=d is solvable if and only if gcd(m, n) divides d. 
     * Therefore we need to check if it satisfies the condition.
     */
    if ( d % gcd_res == 0 ) {
      while ( k != d ) {
        k += n;
        y++;
        if ( k > d ) {
          while ( k > m && k != d) {
            k -= m;
            x--;
          }
        }
      }
    }
    System.out.println("The actual pouring sequence obtaind as following : \nx: " + x + "\ny: " + y );
  }
  
  // this function finds the greates common divisor of two values.
  public static int gcd(int a, int b) {
    if ( b == 0 ) 
      return a;
    return gcd( b, a % b );
  }
}